var refreshToken = null;
var accessToken;
const redirectURL = chrome.identity.getRedirectURL();
const clientId =
  "970247099537-sfqp2piup32cgtpd174ijfl9nmi05rkv.apps.googleusercontent.com";
const clientSecret = "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";
var authcode;
var tokenData;
var accessTokenData;
var user_Profile;
var email_ID_Of_User;
// let GMAIL_MESSAGE_SEND_API = `https://gmail.googleapis.com/gmail/v1/users/me/messages/send`;
SEND_GMAIL_NOTIFICATION_URL =
  "https://us-central1-ws-log-export-to-bq.cloudfunctions.net/function-2";

async function getToken() {
  if (refreshToken == null) {
    const authParams = new URLSearchParams({
      client_id: clientId,
      response_type: "code",
      redirect_uri: redirectURL,
      scope: [
        "https://www.googleapis.com/auth/userinfo.profile",
        "https://www.googleapis.com/auth/userinfo.email",
      ].join(" "),
      access_type: "offline",
      prompt: "consent",
    });

    const authURL = `https://accounts.google.com/o/oauth2/auth?${authParams.toString()}`;
    var responseUrl = await chrome.identity.launchWebAuthFlow({
      url: authURL,
      interactive: true,
    });
    const url = new URL(responseUrl);
    const urlParams = new URLSearchParams(url.search.slice(1));
    const params = Object.fromEntries(urlParams.entries());
    authcode = params["code"];

    const refresh_data = new URLSearchParams({
      code: authcode,
      client_id: clientId,
      client_secret: clientSecret,
      redirect_uri: redirectURL,
      grant_type: "authorization_code",
    });

    const response = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: {
        Host: "oauth2.googleapis.com",
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: refresh_data,
    });
    tokenData = await response.json();
    accessToken = tokenData.access_token;
    refreshToken = tokenData.refresh_token;
    chrome.storage.local.set({ token: refreshToken });
  } else {
    const access_data = new URLSearchParams({
      client_id: clientId,
      client_secret: clientSecret,
      refresh_token: refreshToken,
      grant_type: "refresh_token",
    });
    const token_response = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: {
        Host: "oauth2.googleapis.com",
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: access_data,
    });
    if (token_response.status == 200) {
      accessTokenData = await token_response.json();
      accessToken = accessTokenData.access_token;
      chrome.storage.local.set({ token: refreshToken });
    } else {
      refreshToken = null;
      tokenDetails = await getToken();
      accessToken = tokenDetails.token;
    }
  }
  return accessToken;
}
console.log(accessToken);

async function Send_Button(payload) {
  const response = await fetch(SEND_GMAIL_NOTIFICATION_URL, {
    method: "POST",
    async: true,
    headers: {
      Authorization: "Bearer " + accessToken,
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify(payload),
  });
  console.log("abc", response.body);
  // if (response.status != 200) {
  //   return {
  //     error: "Something went wrong. Please try again after some time.",
  //   };
  // } else {
  let resData = await response.json();
  // return resData;
  console.log(resData);
  // }
}

chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
  if (message.action === "Send_Button") {
    let mdata = message.data;
    const notificationStatus = await Send_Button(mdata);
    sendResponse(notificationStatus);
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "authorization") {
    chrome.storage.local.get("token", function (result) {
      refreshToken = result.token;
      getToken().then(sendResponse);
    });
  }
  return true;
});
