// const close_Icon_SVG = `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0,0,256,256" width="18px" height="18px" fill-rule="nonzero"><g fill="#ABA5A5" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal"><g transform="scale(5.12,5.12)"><path d="M7.71875,6.28125l-1.4375,1.4375l17.28125,17.28125l-17.28125,17.28125l1.4375,1.4375l17.28125,-17.28125l17.28125,17.28125l1.4375,-1.4375l-17.28125,-17.28125l17.28125,-17.28125l-1.4375,-1.4375l-17.28125,17.28125z"></path></g></g></svg>`;

var isPopupVisible = false;
var close_Button;
var Popup_text;
var Sender_Input;
var Receiver_Input;
var SenderLabel;
var ReceiverLabel;
var StartDateLabel;
var Send_Button;
var EndDateLabel;
var StartDateTimePicker;
var EndDateDatePicker;
var checkbox;
var token;
var stn_result;
var mail_of_sender;
var mail_of_receiver;
var start_date;
var end_date;

function closePopup() {
  var popup = document.querySelector(".popup");
  if (popup) {
    popup.remove();
    isPopupVisible = false;
  }
}

function showPopup(elem) {
  var popup = document.createElement("div");
  popup.setAttribute("class", "popup");
  // popup.textContent = "Custom";
  elem.appendChild(popup);
  isPopupVisible = true;
  // popup.addEventListener("click", enableSendButton);

  close_Button = document.createElement("div");
  close_Button.className = "closeButton";
  popup.appendChild(close_Button);
  close_Button.innerHTML = `<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAvklEQVR4nO2VvQ7CIBRGz9M0rlYdLIbBn2iivv8TuFmNxladNCSYENKaKgUWzsTwhcO9AS4kEomADAD5Q34E5K7SDDgAFbDokB8CJXAGxi5iCdyAl5bPv2QnWqiyD2CDIwK46g1rYNnS3lJnnsDeVdokV9VsLenJh/RDAVwM+S6EtKnyu3EQtV7jmakhNKv3ThFDLGK0Wlg3O8jlEtZbXoV4wzNDWrV8IHnfchnry8z+GBLHPoZEtLGYSCToyhtdZ1aPJU42rgAAAABJRU5ErkJggg=="></img>`;
  close_Button.addEventListener("click", closePopup);

  // Popup_text = document.createElement("label");
  // Popup_text.setAttribute("class", "Popuptext");
  // Popup_text.textContent = "Custom";
  // popup.appendChild(Popup_text);

  var SenderLabel = document.createElement("label");
  SenderLabel.textContent = "Sender:";
  SenderLabel.className = "SenderLabel";
  popup.appendChild(SenderLabel);

  Sender_Input = document.createElement("input");
  Sender_Input.className = "searchInput";
  Sender_Input.placeholder = "Enter sender Email ID";
  popup.appendChild(Sender_Input);

  Sender_Input.addEventListener("change", function () {
    mail_of_sender = Sender_Input.value;
  });

  const linesBreak = document.createElement("br");
  popup.appendChild(linesBreak);

  const linesBreak1 = document.createElement("br");
  popup.appendChild(linesBreak1);

  ReceiverLabel = document.createElement("label");
  ReceiverLabel.textContent = "Receiver:";
  ReceiverLabel.className = "ReceiverLabel";
  popup.appendChild(ReceiverLabel);

  Receiver_Input = document.createElement("input");
  Receiver_Input.className = "ReceiverInput";
  Receiver_Input.placeholder = "Enter Receiver Email ID";
  popup.appendChild(Receiver_Input);
  Receiver_Input.addEventListener("change", function () {
    mail_of_receiver = Receiver_Input.value;
  });

  const lineBreak2 = document.createElement("br");
  popup.appendChild(lineBreak2);

  const linesBreak3 = document.createElement("br");
  popup.appendChild(linesBreak3);

  StartDateLabel = document.createElement("label");
  StartDateLabel.textContent = "StartDate:";
  StartDateLabel.className = "StartDateLabel";
  popup.appendChild(StartDateLabel);

  StartDateTimePicker = document.createElement("input");
  StartDateTimePicker.setAttribute("type", "datetime-local");
  StartDateTimePicker.className = "StartDateTimePicker";
  popup.appendChild(StartDateTimePicker);
  StartDateTimePicker.addEventListener("change", function () {
    start_date = new Date().toDateString();
  });

  const lineBreak4 = document.createElement("br");
  popup.appendChild(lineBreak4);

  const linesBreak5 = document.createElement("br");
  popup.appendChild(linesBreak5);

  EndDateLabel = document.createElement("label");
  EndDateLabel.textContent = "EndDate:";
  EndDateLabel.className = "EndDateLabel";
  popup.appendChild(EndDateLabel);

  EndDateDatePicker = document.createElement("input");
  EndDateDatePicker.setAttribute("type", "datetime-local");
  EndDateDatePicker.className = "EndDateTimePicker";
  popup.appendChild(EndDateDatePicker);

  EndDateDatePicker.addEventListener("change", function () {
    end_date = new Date().toDateString();
  });

  const lineBreak6 = document.createElement("br");
  popup.appendChild(lineBreak6);

  const lineBreak7 = document.createElement("br");
  popup.appendChild(lineBreak7);

  const checkbox = document.createElement("input");
  checkbox.setAttribute("type", "checkbox");
  checkbox.className = "Checkbox";

  const checkboxLabel = document.createElement("label");
  checkboxLabel.textContent = "Mark this Checkbox.";
  checkboxLabel.className = "Checkboxtxt";
  popup.appendChild(checkbox);
  popup.appendChild(checkboxLabel);

  Send_Button = document.createElement("div");
  Send_Button.disabled = true;
  Send_Button.className = "SendButton";
  Send_Button.innerHTML = "Send";
  popup.appendChild(Send_Button);
  Send_Button.addEventListener("click", async function () {
    console.log("sent");
    token = await chrome.runtime.sendMessage({ action: "authorization" });
    let payload = {
      sender_Input: mail_of_sender,
      receiver_input: mail_of_receiver,
      startdate: start_date,
      enddate: end_date,
    };
    console.log(payload);
    stn_result = await chrome.runtime.sendMessage({
      action: "Send_Button",
      data: payload,
    });
    console.log("data", data);
  });

  checkbox.addEventListener("click", function () {
    console.log("Checkbox clicked. Checked:", checkbox.checked);
    if (checkbox.checked) {
      Send_Button.disabled = false;
      Send_Button.classList.add("disabled");
    } else {
      Send_Button.disabled = true;
      Send_Button.classList.remove("disabled");
    }
  });
}

const initExtraStyle = (elem) => {
  var eventButton = document.createElement("div");
  eventButton.innerHTML = `<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAwUlEQVR4nGNgGDLgJQ+PzUsennJ8+AUvryXxBvLyNrzi5f2PD7/k5b32n4GBiTQDeXhCX/PzG6PjVzw8k6AGX37Jw3MGGb/m4UnDaeBzbm5tbBZ+4OMTesXDcxzFMF7eq1CXN5BsIDYAUvtq1EBSk80MksPwFQ/Pjle8vKswMA/P3Ze8vD9f8vLGgpIWGPPyFpEdKS+4uV3wuLyBZAPBhvLw+MNdh4SfY9NDTjrEC14OegNfQAK94wU3tzhVDBy0AAAMetlFT/vudAAAAABJRU5ErkJggg=="></img>`;
  eventButton.style =
    "margin-left: 35%;width: 00px;margin-top: 20%;height: 00px;cursor: pointer";
  // eventButton.setAttribute("class", "eventbutton");
  // eventButton.textContent.style = "margin-left: 20%; role:heading";
  eventButton.addEventListener("mouseover", function () {});
  eventButton.addEventListener("mouseout", function () {});
  eventButton.setAttribute("title", "Follow Up");
  eventButton.addEventListener("click", () => {
    console.log("clicked");
    if (isPopupVisible) {
      closePopup();
    } else {
      showPopup(elem);
    }
  });
  return eventButton;
};
const initExtraStyling = (elem) => {
  var dvelem3 = document.createElement("div");
  dvelem3.classList.add("G-Ni");
  dvelem3.classList.add("J-J5-Ji");
  dvelem3.appendChild(initExtraStyle(elem));
  elem.appendChild(dvelem3);
};

const initTemplate = () => {
  var interval = setInterval(function () {
    var elem = document.querySelector(".iH");
    if (elem) {
      clearInterval(interval);
      initExtraStyling(elem);
    }
  }, 100);
};
initTemplate();
